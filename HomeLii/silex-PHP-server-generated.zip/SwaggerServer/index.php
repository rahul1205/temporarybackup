<?php
require_once __DIR__ . '/vendor/autoload.php';

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Silex\Application;

$app = new Silex\Application();


$app->POST('/v2/device', function(Application $app, Request $request) {
            
            
            return new Response('How about implementing addDevice as a POST method ?');
            });


$app->GET('/v2/device/{username}/{device_id}', function(Application $app, Request $request, $username, $device_id) {
            
            
            return new Response('How about implementing deviceSensor as a GET method ?');
            });


$app->GET('/v2/device/status/{device_id}', function(Application $app, Request $request, $device_id) {
            
            
            return new Response('How about implementing deviceStatus as a GET method ?');
            });


$app->PUT('/v2/device', function(Application $app, Request $request) {
            
            
            return new Response('How about implementing updateDevice as a PUT method ?');
            });


$app->GET('/v2/event/status/{account_number}/{event_code}', function(Application $app, Request $request, $account_number, $event_code) {
            
            
            return new Response('How about implementing eventStatus as a GET method ?');
            });


$app->POST('/v2/event/trigger/{account_number}/{event_code}', function(Application $app, Request $request, $event_code, $account_number) {
            $onoff = $request->get('onoff');    $apn = $request->get('apn');    $apn_name = $request->get('apn_name');    $pwd = $request->get('pwd');    $ip = $request->get('ip');    $port = $request->get('port');    $user_id = $request->get('user_id');    $group = $request->get('group');    $number = $request->get('number');    $alarming_delay = $request->get('alarming_delay');    $disalarming_delay = $request->get('disalarming_delay');    $time = $request->get('time');    $attribute = $request->get('attribute');    
            
            return new Response('How about implementing eventTrigger as a POST method ?');
            });


$app->POST('/v2/sensor', function(Application $app, Request $request) {
            
            
            return new Response('How about implementing addSensor as a POST method ?');
            });


$app->GET('/v2/sensor/status/{sensor_id}', function(Application $app, Request $request, $sensor_id) {
            
            
            return new Response('How about implementing sensorStatus as a GET method ?');
            });


$app->PUT('/v2/sensor/{seriel_number}', function(Application $app, Request $request, $seriel_number) {
            
            
            return new Response('How about implementing updateSensor as a PUT method ?');
            });


$app->POST('/v2/user', function(Application $app, Request $request) {
            
            
            return new Response('How about implementing userCreate as a POST method ?');
            });


$app->GET('/v2/user/getaccountdetails/{username}', function(Application $app, Request $request, $username) {
            
            
            return new Response('How about implementing userDetail as a GET method ?');
            });


$app->GET('/v2/user/getdevicesassigned/{username}', function(Application $app, Request $request, $username) {
            
            
            return new Response('How about implementing userDevices as a GET method ?');
            });


$app->POST('/v2/user/login', function(Application $app, Request $request) {
            $username = $request->get('username');    $password = $request->get('password');    
            
            return new Response('How about implementing userLogin as a POST method ?');
            });


$app->GET('/v2/user/logout', function(Application $app, Request $request) {
            
            
            return new Response('How about implementing userLogout as a GET method ?');
            });


$app->run();
